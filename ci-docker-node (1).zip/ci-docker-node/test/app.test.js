const request = require("supertest");
const app = require("../src/app");

describe("GET /", () => {
  it("deve retornar status 200", async () => {
    const response = await request(app).get("/");
    expect(response.statusCode).toBe(200);
  });
});


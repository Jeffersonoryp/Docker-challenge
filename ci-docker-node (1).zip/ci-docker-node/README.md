# Projeto CI, Docker e DevSecOps

## Descrição
Aplicação Node.js simples com pipeline de Integração Contínua, Docker multi-stage e verificação de segurança.

## Tecnologias
- Node.js
- Express
- Docker
- GitHub Actions
- npm audit

## Como executar
```bash
npm install
npm start

